This application note illustrates an SPI-based interface between
AT89LP microcontrollers and the AT25CXX-type serial EEPROMs.
The text for "Interfacing AT25CXX Serial EEPROMs with AT89LP
Microcontrollers" can be found on the Atmel Web site www.atmel.com.

The following files pertain to the application note:

AT25CXX.SCH        ORCAD schematic file
AT25CXX.ASM        80C51 assembly source code
AT25CXX.LIB        ORCAD library file for the schematics